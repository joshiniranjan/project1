jQuery(function() {
	tabHover();
	initMobileNav();
	initTabs();
	initHoverClass();
	initAddClasses();
});

function tabHover() {
	wrap = $('.image-list');
	opener = wrap.find('a.tab-link');
	opener.each(function() {
		var self = jQuery(this);
		$(window).on('resize load', function() {
			var width = $(window).width();
			// console.log(width);
			hoverList(width, self);
		});

		self.on('click' , function(e) {
			e.preventDefault();
			var title = $(this).attr('href');

			$('.service-wrap .tab-content').find("." + title).addClass('active').removeClass('js-tab-hidden').siblings().removeClass('active').addClass('js-tab-hidden');
			$("a[title|='service-active']").parent().addClass('active');
			$('.service-wrap .tabset').find("." + title).parent().addClass('active').siblings().removeClass('active');
			jQuery('.tabset').tabset({
				tabLinks: 'a',
				addToParent: true,
				event: 'click'
			});
		});
	});
	function hoverList(w, elem) {
		if(w >= 768) {
			elem.hover(function() {
				var title = $($(this).attr('title'));
				title.toggleClass('active');
				var parent = title.parent().toggleClass('default');
				$('.text-hold .content').fadeIn(2000);
			});
		}
	}

}


/*
 * Window Height CSS rules
 */
 ;(function() {
 	var styleSheet;

 	var getWindowHeight = function() {
 		return window.innerHeight || document.documentElement.clientHeight;
 	};

 	var createStyleTag = function() {
		// create style tag
		var styleTag = jQuery('<style>').appendTo('head');
		styleSheet = styleTag.prop('sheet') || styleTag.prop('styleSheet');

		// crossbrowser style handling
		var addCSSRule = function(selector, rules, index) {
			if(styleSheet.insertRule) {
				styleSheet.insertRule(selector + '{' + rules + '}', index);
			} else {
				styleSheet.addRule(selector, rules, index);
			}
		};

		// create style rules
		addCSSRule('.win-min-height', 'min-height:0');
		addCSSRule('.win-height', 'height:auto');
		addCSSRule('.win-max-height', 'max-height:100%');
		resizeHandler();
	};

	var resizeHandler = function() {
		// handle changes in style rules
		var currentWindowHeight = getWindowHeight(),
		styleRules = styleSheet.cssRules || styleSheet.rules;

		jQuery.each(styleRules, function(index, currentRule) {
			var currentProperty = currentRule.selectorText.toLowerCase().replace('.win-', '').replace('-h','H');
			currentRule.style[currentProperty] = currentWindowHeight + 'px';
		});
	};

	createStyleTag();
	jQuery(window).on('resize orientationchange', resizeHandler);
}());

 function draw(){
 	for(i=0;i<60;i++){
 		D = (i<10) ? '0'+i : i;
 		$('#s').append('<li data-item='+D+'>'+D+'</li>');
 	}
 	for(i=0;i<60;i++){
 		D = (i<10) ? '0'+i : i;
 		$('#m').append('<li data-item='+D+'>'+D+'</li>');
 	}
 	for(i=0;i<24;i++){
 		D = (i<10) ? '0'+i : i;
 		$('#h').append('<li data-item='+D+'>'+D+'</li>');
 	}
 }
 function place(){
 	hdeg = 15;
 	msdeg = 6;
 	$('#s li').each(function(index){
 		$(this).css({transform: 'rotateZ('+msdeg * index +'deg) translateX('+ parseInt(200) +'px)'});
 	});
 	$('#m li').each(function(index){
 		$(this).css({transform: 'rotateZ('+msdeg * index +'deg) translateX('+ parseInt(170) +'px)'});
 	});
 	$('#h li').each(function(index){
 		$(this).css({transform: 'rotateZ('+hdeg * index +'deg) translateX('+ parseInt(140) +'px)'});
 	});
 }
//TIMER
function sec(ts,timer){
	TS = ts % 60;
	if(ts == 0 && timer) min(0,timer);
	deg = 360/60 * ts;
	$('#s li').removeClass('active');
	$('#s li').eq(TS).addClass('active');
	$('#s').css({transform: 'rotateZ(-'+deg+'deg)'});
	ts++;
	if(timer) setTimeout(function(){sec(ts,timer)},TIME * 1000);
}
function min(tm,timer){
	TM = tm % 60;
	if(tm == 0 && timer) hour(0,timer);
	deg = 360/60 * tm;
	$('#m li').removeClass('active');
	$('#m li').eq(TM).addClass('active');
	$('#m').css({transform: 'rotateZ(-'+deg+'deg)'});
	tm++;
	if(timer) setTimeout(function(){min(tm,timer)}, TIME * 60000);
}
function hour(th,timer){
	TH = th % 24;
	deg = 360/24 * th;
	$('#h li').removeClass('active');
	$('#h li').eq(TH).addClass('active');
	$('#h').css({transform: 'rotateZ(-'+deg+'deg)'});
	th++;
	if(timer) setTimeout(function(){hour(th,timer)}, TIME * 3600000);
}
//CLOCK
function clock(){
	d = new Date();
	H = d.getHours();
	M = d.getMinutes();
	S = d.getSeconds();
	hour(H,0);
	min(M,0);
	sec(S,0);
	setTimeout(function(){clock();},1000);
}

$(document).ready(function(){
	draw();
	place();
  //TIMER
  /*
  TIME = 1;
  sec(0,1);
  */
  //CLOCK
  clock();
  //LIGHT
  $(".ligh-on").click(function(){
  	$(this).toggleClass('off');
  });
});

;(function(w) {
	w.addEventListener('load', function() {
		var loader = document.querySelector('body.main-active');

		if (loader) {
			loader.classList.add('loaded');
		}
	});
}(window));

// content tabs init
function initTabs() {
	// jQuery('.image-list').tabset({
	// 	tabLinks: 'a.tab-link',
	// 	addToParent: true,
	// 	event: 'mouseenter',
	// 	attrib: 'title',
	// 	defaultTab: true
	// });

	jQuery('.tabset').tabset({
		tabLinks: 'a',
		addToParent: true,
		event: 'click',
		defaultTab: true
	});
}

// add class on click
function initAddClasses() {
	jQuery('.image-list').clickClass({
		classAdd: 'popup-active',
		opener : '.tab-link',
		addToParent: 'body'
	});
}


function initHoverClass() {
	jQuery('#nav').hoverClass({
		hoverLink: '.nav-link',
		addToParent: 'body'
	});
	jQuery('.image-list').hoverClass({
		hoverLink: '.tree a',
		addToParent: 'body'
	});
	jQuery('.text-block').hoverClass({
		hoverLink: 'a',
		addToParent: 'body'
	});
	jQuery('.text-hold').hoverClass({
		hoverLink: 'a',
		addToParent: 'body'
	});
}



/*
 * Add class plugin
 */
 jQuery.fn.clickClass = function(opt) {
 	var options = jQuery.extend({
 		classAdd: 'add-class',
 		addToParent: false,
 		opener: 'tab-link',
 		event: 'click'
 	}, opt);

 	return this.each(function() {
 		var classItem = jQuery(this);
 		classad = $(this).find('.tab-link');

 		classad.each(function(index, item) {
 			$(this).bind(options.event, function(e) {
 				x= $(this).attr('data-label');
 				name= $(this).attr('data-label');
 				oldClass = $('body').attr('class');

 				if($('body').hasClass(oldClass) === true) {
 					$('body').delay(10000).removeClass(oldClass)	;
 					$('body').delay(10000).addClass(name);
 				}

 				else {
 					$('body').delay(10000).addClass(name);
 				}
 				e.preventDefault();
 			});
 		});
 	});
 };

// mobile menu init
function initMobileNav() {
	ResponsiveHelper.addRange({
		'..767': {
			on: function() {
				jQuery('body').mobileNav({
					menuActiveClass: 'nav-active',
					menuOpener: '.nav-opener',
					hideOnClickOutside: true,
					menuDrop: '.nav-drop'
				});
			},
			off: function() {
				jQuery('body').mobileNav('destroy');
			}
		}
	});
}

;(function($) {

	$.fn.hoverClass = function(options) {
		var defaults = $.extend({
			hoverLink: 'a',
			addToParent: 'body'
		},options= $.extend(defaults,options));

		return this.each (function() {
			wrap = options.addToParent;
			opener = $(this).find(options.hoverLink);
			opener.each(function(index, item) {
				$(this).bind('click', function() {
					name= $(this).attr('title');
					oldClass = $('body').attr('class');
					if($('body').hasClass(oldClass) === true) {
						$('body').removeClass(oldClass)	;
						$('body').addClass(name);
						$(this).parent().addClass('active').siblings().removeClass('active');


						if($('body').hasClass('service-active')===true){
							$('.service-wrap').addClass('anim');
						}
						else 
							$('.service-wrap').removeClass('anim');
					}
					else {
						$('body').addClass(name);
					}

				});
			});
		});
	}

	

}(jQuery));

/*
 * jQuery Tabs plugin
 */

 ;(function($, $win) {

 	'use strict';

 	function Tabset($holder, options) {
 		this.$holder = $holder;
 		this.options = options;

 		this.init();
 	}

 	Tabset.prototype = {
 		init: function() {
 			this.$tabLinks = this.$holder.find(this.options.tabLinks);

 			this.setStartActiveIndex();
 			this.setActiveTab();

 			if (this.options.autoHeight) {
 				this.$tabHolder = $(this.$tabLinks.eq(0).attr(this.options.attrib)).parent();
 			}

 			this.makeCallback('onInit', this);
 		},

 		setStartActiveIndex: function() {
 			var $classTargets = this.getClassTarget(this.$tabLinks);
 			var $activeLink = $classTargets.filter('.' + this.options.activeClass);
 			var $hashLink = this.$tabLinks.filter('[' + this.options.attrib + '="' + location.hash + '"]');
 			var activeIndex;

 			if (this.options.checkHash && $hashLink.length) {
 				$activeLink = $hashLink;
 			}

 			activeIndex = $classTargets.index($activeLink);

 			this.activeTabIndex = this.prevTabIndex = (activeIndex === -1 ? (this.options.defaultTab ? 0 : null) : activeIndex);
 		},

 		setActiveTab: function() {
 			var self = this;

 			this.$tabLinks.each(function(i, link) {
 				var $link = $(link);
 				var $classTarget = self.getClassTarget($link);
 				var $tab = $($link.attr(self.options.attrib));

 				if (i !== self.activeTabIndex) {
 					$classTarget.removeClass(self.options.activeClass);
 					$tab.addClass(self.options.tabHiddenClass).removeClass(self.options.activeClass);
 				} else {
 					$classTarget.addClass(self.options.activeClass);
 					$tab.removeClass(self.options.tabHiddenClass).addClass(self.options.activeClass);
 				}

 				self.attachTabLink($link, i);
 			});
 		},

 		attachTabLink: function($link, i) {
 			var self = this;

 			$link.on(this.options.event + '.tabset', function(e) {
 				e.preventDefault();

 				if (self.activeTabIndex === self.prevTabIndex && self.activeTabIndex !== i) {
 					self.activeTabIndex = i;
 					self.switchTabs();
 				}
 			});
 		},

 		resizeHolder: function(height) {
 			var self = this;

 			if (height) {
 				this.$tabHolder.height(height);
 				setTimeout(function() {
 					self.$tabHolder.addClass('transition');
 				}, 10);
 			} else {
 				self.$tabHolder.removeClass('transition').height('');
 			}
 		},

 		switchTabs: function() {
 			var self = this;

 			var $prevLink = this.$tabLinks.eq(this.prevTabIndex);
 			var $nextLink = this.$tabLinks.eq(this.activeTabIndex);

 			var $prevTab = this.getTab($prevLink);
 			var $nextTab = this.getTab($nextLink);

 			$prevTab.removeClass(this.options.activeClass);

 			if (self.haveTabHolder()) {
 				this.resizeHolder($prevTab.outerHeight());
 			}

 			setTimeout(function() {
 				self.getClassTarget($prevLink).removeClass(self.options.activeClass);

 				$prevTab.addClass(self.options.tabHiddenClass);
 				$nextTab.removeClass(self.options.tabHiddenClass).addClass(self.options.activeClass);

 				self.getClassTarget($nextLink).addClass(self.options.activeClass);

 				if (self.haveTabHolder()) {
 					self.resizeHolder($nextTab.outerHeight());

 					setTimeout(function() {
 						self.resizeHolder();
 						self.prevTabIndex = self.activeTabIndex;
 						self.makeCallback('onChange', self);
 					}, self.options.animSpeed);
 				} else {
 					self.prevTabIndex = self.activeTabIndex;
 				}
 			}, this.options.autoHeight ? this.options.animSpeed : 1);
 		},

 		getClassTarget: function($link) {
 			return this.options.addToParent ? $link.parent() : $link;
 		},

 		getActiveTab: function() {
 			return this.getTab(this.$tabLinks.eq(this.activeTabIndex));
 		},

 		getTab: function($link) {
 			return $($link.attr(this.options.attrib));
 		},

 		haveTabHolder: function() {
 			return this.$tabHolder && this.$tabHolder.length;
 		},

 		destroy: function() {
 			var self = this;

 			this.$tabLinks.off('.tabset').each(function() {
 				var $link = $(this);

 				self.getClassTarget($link).removeClass(self.options.activeClass);
 				$($link.attr(self.options.attrib)).removeClass(self.options.activeClass + ' ' + self.options.tabHiddenClass);
 			});

 			this.$holder.removeData('Tabset');

 		},

 		makeCallback: function(name) {
 			if (typeof this.options[name] === 'function') {
 				var args = Array.prototype.slice.call(arguments);
 				args.shift();
 				this.options[name].apply(this, args);
 			}
 		}
 	};

 	$.fn.tabset = function(opt) {
 		var args = Array.prototype.slice.call(arguments);
 		var method = args[0];

 		var options = $.extend({
 			activeClass: 'active',
 			addToParent: false,
 			autoHeight: false,
 			checkHash: false,
 			defaultTab: true,
 			animSpeed: 500,
 			tabLinks: 'a',
 			attrib: 'href',
 			event: 'click',
 			tabHiddenClass: 'js-tab-hidden'
 		}, opt);
 		options.autoHeight = options.autoHeight && $.support.opacity;

 		return this.each(function() {
 			var $holder = jQuery(this);
 			var instance = $holder.data('Tabset');

 			if (typeof opt === 'object' || typeof opt === 'undefined') {
 				$holder.data('Tabset', new Tabset($holder, options));
 			} else if (typeof method === 'string' && instance) {
 				if (typeof instance[method] === 'function') {
 					args.shift();
 					instance[method].apply(instance, args);
 				}
 			}
 		});
 	};
 }(jQuery, jQuery(window)));

/*
 * Simple Mobile Navigation
 */
 ;(function($) {
 	function MobileNav(options) {
 		this.options = $.extend({
 			container: null,
 			hideOnClickOutside: false,
 			menuActiveClass: 'nav-active',
 			menuOpener: '.nav-opener',
 			menuDrop: '.nav-drop',
 			toggleEvent: 'click',
 			outsideClickEvent: 'click touchstart pointerdown MSPointerDown'
 		}, options);
 		this.initStructure();
 		this.attachEvents();
 	}
 	MobileNav.prototype = {
 		initStructure: function() {
 			this.page = $('html');
 			this.container = $(this.options.container);
 			this.opener = this.container.find(this.options.menuOpener);
 			this.drop = this.container.find(this.options.menuDrop);
 		},
 		attachEvents: function() {
 			var self = this;

 			if(activateResizeHandler) {
 				activateResizeHandler();
 				activateResizeHandler = null;
 			}

 			this.outsideClickHandler = function(e) {
 				if(self.isOpened()) {
 					var target = $(e.target);
 					if(!target.closest(self.opener).length && !target.closest(self.drop).length) {
 						self.hide();
 					}
 				}
 			};

 			this.openerClickHandler = function(e) {
 				e.preventDefault();
 				self.toggle();
 			};

 			this.opener.on(this.options.toggleEvent, this.openerClickHandler);
 		},
 		isOpened: function() {
 			return this.container.hasClass(this.options.menuActiveClass);
 		},
 		show: function() {
 			this.container.addClass(this.options.menuActiveClass);
 			if(this.options.hideOnClickOutside) {
 				this.page.on(this.options.outsideClickEvent, this.outsideClickHandler);
 			}
 		},
 		hide: function() {
 			this.container.removeClass(this.options.menuActiveClass);
 			if(this.options.hideOnClickOutside) {
 				this.page.off(this.options.outsideClickEvent, this.outsideClickHandler);
 			}
 		},
 		toggle: function() {
 			if(this.isOpened()) {
 				this.hide();
 			} else {
 				this.show();
 			}
 		},
 		destroy: function() {
 			this.container.removeClass(this.options.menuActiveClass);
 			this.opener.off(this.options.toggleEvent, this.clickHandler);
 			this.page.off(this.options.outsideClickEvent, this.outsideClickHandler);
 		}
 	};

 	var activateResizeHandler = function() {
 		var win = $(window),
 		doc = $('html'),
 		resizeClass = 'resize-active',
 		flag, timer;
 		var removeClassHandler = function() {
 			flag = false;
 			doc.removeClass(resizeClass);
 		};
 		var resizeHandler = function() {
 			if(!flag) {
 				flag = true;
 				doc.addClass(resizeClass);
 			}
 			clearTimeout(timer);
 			timer = setTimeout(removeClassHandler, 500);
 		};
 		win.on('resize orientationchange', resizeHandler);
 	};

 	$.fn.mobileNav = function(opt) {
 		var args = Array.prototype.slice.call(arguments);
 		var method = args[0];

 		return this.each(function() {
 			var $container = jQuery(this);
 			var instance = $container.data('MobileNav');

 			if (typeof opt === 'object' || typeof opt === 'undefined') {
 				$container.data('MobileNav', new MobileNav($.extend({
 					container: this
 				}, opt)));
 			} else if (typeof method === 'string' && instance) {
 				if (typeof instance[method] === 'function') {
 					args.shift();
 					instance[method].apply(instance, args);
 				}
 			}
 		});
 	};
 }(jQuery));


/*
 * Responsive Layout helper
 */
 window.ResponsiveHelper = (function($){
	// init variables
	var handlers = [],
	prevWinWidth,
	win = $(window),
	nativeMatchMedia = false;

	// detect match media support
	if(window.matchMedia) {
		if(window.Window && window.matchMedia === Window.prototype.matchMedia) {
			nativeMatchMedia = true;
		} else if(window.matchMedia.toString().indexOf('native') > -1) {
			nativeMatchMedia = true;
		}
	}

	// prepare resize handler
	function resizeHandler() {
		var winWidth = win.width();
		if(winWidth !== prevWinWidth) {
			prevWinWidth = winWidth;

			// loop through range groups
			$.each(handlers, function(index, rangeObject){
				// disable current active area if needed
				$.each(rangeObject.data, function(property, item) {
					if(item.currentActive && !matchRange(item.range[0], item.range[1])) {
						item.currentActive = false;
						if(typeof item.disableCallback === 'function') {
							item.disableCallback();
						}
					}
				});

				// enable areas that match current width
				$.each(rangeObject.data, function(property, item) {
					if(!item.currentActive && matchRange(item.range[0], item.range[1])) {
						// make callback
						item.currentActive = true;
						if(typeof item.enableCallback === 'function') {
							item.enableCallback();
						}
					}
				});
			});
		}
	}
	win.bind('load resize orientationchange', resizeHandler);

	// test range
	function matchRange(r1, r2) {
		var mediaQueryString = '';
		if(r1 > 0) {
			mediaQueryString += '(min-width: ' + r1 + 'px)';
		}
		if(r2 < Infinity) {
			mediaQueryString += (mediaQueryString ? ' and ' : '') + '(max-width: ' + r2 + 'px)';
		}
		return matchQuery(mediaQueryString, r1, r2);
	}

	// media query function
	function matchQuery(query, r1, r2) {
		if(window.matchMedia && nativeMatchMedia) {
			return matchMedia(query).matches;
		} else if(window.styleMedia) {
			return styleMedia.matchMedium(query);
		} else if(window.media) {
			return media.matchMedium(query);
		} else {
			return prevWinWidth >= r1 && prevWinWidth <= r2;
		}
	}

	// range parser
	function parseRange(rangeStr) {
		var rangeData = rangeStr.split('..');
		var x1 = parseInt(rangeData[0], 10) || -Infinity;
		var x2 = parseInt(rangeData[1], 10) || Infinity;
		return [x1, x2].sort(function(a, b){
			return a - b;
		});
	}

	// export public functions
	return {
		addRange: function(ranges) {
			// parse data and add items to collection
			var result = {data:{}};
			$.each(ranges, function(property, data){
				result.data[property] = {
					range: parseRange(property),
					enableCallback: data.on,
					disableCallback: data.off
				};
			});
			handlers.push(result);

			// call resizeHandler to recalculate all events
			prevWinWidth = null;
			resizeHandler();
		}
	};
}(jQuery));